Role Apache
=========

Install Apache2, create index.html and check start status.

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

- hosts: all
  become: yes
  name: task_3-1
  
  roles:
    - apache

License
-------

BSD

Author Information
------------------

Klochek M.E.
